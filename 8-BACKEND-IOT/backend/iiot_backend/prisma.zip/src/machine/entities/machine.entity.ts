export class Machine {}
